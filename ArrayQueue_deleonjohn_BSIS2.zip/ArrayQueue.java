
public class ArrayQueue {

	
	int qsize;
	 private int nItems;
	 private int[] queue;
	 
	 
	 public ArrayQueue(int size){
	  this.qsize=size;
	  
	  this.queue= new int [this.qsize];
	 }

	 public void showQueue(){
	 for (int i=0;i<this.qsize;i++){
	  System.out.printf("Queue["+i+"]="+this.queue[i]+"\n");
	 }
	 }
	 
	 public void enQueue(){
		 int a=10;
	  for (int i=0;i<this.qsize;i++){
	    
 
	    
	    this.queue[i]=a--;
	   
	  }
	  
	 }
	 
	 public void deQueue(){
		
	  for (int i=0;i<this.qsize;i++){
	    
		  this.queue[i]=0;
	   
	  }
	  
	 }
	 
	 public void peekFront(){
		 System.out.println(this.queue[0]);
	 }
	 public void peekRear(){
		
		 System.out.println(this.queue[9]);
	 }

	 
	 public static void main(String[]args){
	  
	  ArrayQueue queue = new ArrayQueue(10);
	  
	  System.out.println("\nshowqueue\n");
	  queue.showQueue();
	  queue.enQueue();
	  System.out.println("\nenqueue\n");
	  queue.showQueue();
	  System.out.println("\npeekFront\n");
	  queue.peekFront();
	  System.out.println("\npeekRear\n");
	  queue.peekRear();
	  System.out.println("\ndeQueue\n");
	  queue.deQueue();
	  queue.showQueue();
	 }
	 
}
